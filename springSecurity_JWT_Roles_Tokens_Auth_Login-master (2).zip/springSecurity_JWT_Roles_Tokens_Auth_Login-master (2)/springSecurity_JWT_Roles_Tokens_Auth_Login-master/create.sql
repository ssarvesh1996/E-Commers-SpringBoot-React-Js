
    create table ourusers (
        id integer not null auto_increment,
        email varchar(255),
        password varchar(255),
        role varchar(255),
        primary key (id)
    ) engine=InnoDB;

    create table products (
        id integer not null auto_increment,
        name varchar(255),
        primary key (id)
    ) engine=InnoDB;
